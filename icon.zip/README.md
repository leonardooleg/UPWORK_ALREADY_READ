<h1>A simple extension that will remind you where you last stopped viewing jobs </h1><br>


<br>[Chrome web store: UPWORK ALREADY READ](https://chrome.google.com/webstore/detail/upwork-already-read/ejbaepaapdgjhookdageiidjkffpejpf/related)
<br>

-----------------------------------------------
<h5>v.1.2.1 - added automatic page scrolling and tag correction</h5>
<h5>v.1.1.9 - add old already read</h5>
-----------------------------------------------


<h1>*-*-*-*-*-*-*-UA-*-*-*-*-*-*-*</h1>
<h2>Просте розширення яке допоможе нагадати яку останню вакансію ви переглядали</h2>
-----------------------------------------------
<h5>v.1.2.1 - доданий автоматичний скрол сторінки та корекція роботи міток</h5>
<h5>v.1.1.9 - додана додаткова позначка про переглянуте ще раніше</h5>
-----------------------------------------------

<div style=" display: block;
  margin-left: auto;
  margin-right: auto;" >


![](1.png)

![](3.png)


</div>
